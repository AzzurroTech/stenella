# stenella
Advanced AI platform allowing for operations to be run from a single platform based on exactly how the company operates
